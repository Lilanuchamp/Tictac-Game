import java.util.Scanner;

public class NoughtsAndCosses {
    public char gameBoard [][];
    public char currentlyPlacedMark;

     //Constructor to Initialize the board

    public NoughtsAndCosses() {
        gameBoard = new char[3][3];
        currentlyPlacedMark = 'x';
        initializeNGBoard();

    }

    //Gives us access to currentPlacedMark
    public char getCurrentPlayerMark()
    {
        return currentlyPlacedMark;
    }

    // Set/Reset the  game board back.
    public void initializeNGBoard() {

        // Loop through rows
        for (int i = 0; i < 3; i++) {
            // Loop through columns
            for (int j = 0; j < 3; j++) {
                gameBoard[i][j] = '-';
            }
        }
    }
    public void printNGBoard() {
        System.out.println("-------------");

        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(gameBoard[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    // Loop through all cells of the board and if one is found to be empty (contains char '-') then return false.
        public boolean isGameBoardFull() {
        boolean isFull = true;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (gameBoard[i][j] == '-') {
                    isFull = false;
                }
            }
        }

        return isFull;
    }
    // Returns true if there is a win, false otherwise.

    public boolean checkGameWon() {
        return (checkRows() || checkColumns() || checkDiagonals());
    }


    // Loop through rows for win
    private boolean checkRows() {
        for (int i = 0; i < 3; i++) {
            if (checkRowCol(gameBoard[i][0], gameBoard[i][1], gameBoard[i][2]) == true) {
                return true;
            }
        }
        return false;
    }

    // Loop through columns for win
    private boolean checkColumns() {
        for (int i = 0; i < 3; i++) {
            if (checkRowCol(gameBoard[0][i], gameBoard[1][i], gameBoard[2][i]) == true) {
                return true;
            }
        }
        return false;
    }
    // Check the two diagonals for win
    private boolean checkDiagonals() {
        return ((checkRowCol(gameBoard[0][0], gameBoard[1][1], gameBoard[2][2]) == true) || (checkRowCol(gameBoard[0][2], gameBoard[1][1], gameBoard[2][0]) == true));
    }



    // Check to see if all three values are the same (and not empty) indicating a win.
    private boolean checkRowCol(char c1, char c2, char c3) {
        return ((c1 != '-') && (c1 == c2) && (c2 == c3));
    }
// give players their turns to play
    public void changePlayer() {
        if (currentlyPlacedMark == 'x') {
            currentlyPlacedMark = 'o';
        }
        else {
            currentlyPlacedMark = 'x';
        }
    }

    // Places a mark at the cell specified by row and col with the mark of the current player.
    public boolean playerPlacedMark(int row, int col) {

        // Make sure that row and column are in bounds of the board.
        if ((row >= 0) && (row < 3)) {
            if ((col >= 0) && (col < 3)) {
                if (gameBoard[row][col] == '-') {
                    gameBoard[row][col] = currentlyPlacedMark;
                    return true;
                }
            }
        }

        return false;
    }

// Start the Game by taking Players Inputs

 public static void startTheGame()
 {
     Scanner scan = new Scanner(System.in);
     NoughtsAndCosses  newGame = new NoughtsAndCosses();
     newGame.initializeNGBoard();
     System.out.println("WELCOME TO NOUGHTS AND CROSSES");
     do
     {
         System.out.println("Current board layout:");
         newGame.printNGBoard();
         int row;
         int col;
         do
         {
             System.out.println("Player " + newGame.getCurrentPlayerMark() + ", enter an empty row and column to place your mark!");
             System.out.println("Enter Row Number form [1,2,3] which tells first,second,third Column respectively\n");
             row = scan.nextInt()-1;
             System.out.println("Enter Column Number form [1,2,3] which tells first,second,third Column respectively\n");
             col = scan.nextInt()-1;
         }

         while (!newGame.playerPlacedMark(row, col));
         newGame.changePlayer();
     }
     while(!newGame.checkGameWon() && !newGame.isGameBoardFull());
     if (newGame.isGameBoardFull() && !newGame.checkGameWon())
     {
         System.out.println("The game was a tie!");
     }
     else
     {
         System.out.println("Current board layout:");
         newGame.printNGBoard();
         newGame.changePlayer();
         System.out.println(Character.toUpperCase(newGame.getCurrentPlayerMark()) + " Wins!");
     }
 }

}

