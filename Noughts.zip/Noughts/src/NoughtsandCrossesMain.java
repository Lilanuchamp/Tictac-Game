public class NoughtsandCrossesMain {

    public static void main(String args[]) {
        NoughtsAndCosses.startTheGame();

    }
}
